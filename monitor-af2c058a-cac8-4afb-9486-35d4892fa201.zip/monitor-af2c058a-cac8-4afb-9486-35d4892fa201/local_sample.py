import os
from unittest.mock import patch

import lambda_function


def run_local_sample():
    """Run the Lambda handler locally without making any real GitHub API calls."""
    os.environ["GIT_FINE_GRAIN_TOKEN"] = "fake-token-for-local-testing"

    event = {
        "branch": "main",
        "workflow": "sample.yml",
    }

    with patch("lambda_function.GitHubOps.run_workflow") as mock_run_workflow:
        response = lambda_function.lambda_handler(event, None)
        print("Lambda response:")
        print(response)
        print("\nGitHub workflow mock called with:")
        print(mock_run_workflow.call_args)


if __name__ == "__main__":
    run_local_sample()
